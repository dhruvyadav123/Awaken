"use client";
import Overview from "./Overview";
import DigitalLibrary from "@/components/user/profile/DigitalLibrary";
import UserResources, { LearningProgress } from "./UserResources";
import FacilitatorResources from "./FacilitatorResources";
import FacilitatorCategories from "./FacilitatorCategories";
import FacilitatorProfile from "./FacilitatorProfile";
import MediaLibrary from "./MediaLibrary";
import TeachingScope from "./TeachingScope";
import Analytics from "./Analytics";
import Earnings from "./Earnings";
import AccountSettings from "./AccountSettings";
import ApplicationWizard from "./ApplicationWizard";
import { State } from "./Elements";
import { useWorkspace } from "./WorkspaceShell";
import CourseSpace from "@/components/user/learning/CourseSpace";
import LessonSpace from "@/components/user/learning/LessonSpace";
import MyCourses from "@/components/user/learning/MyCourses";
import ClassSpace from "@/components/user/learning/ClassSpace";
import Questions from "@/components/user/learning/Questions";
import MyNotifications from "@/components/user/profile/MyNotifications";
import MySessions from "@/components/user/sessions/MySessions";
import CommerceCenter from "@/components/user/commerce/CommerceCenter";
import MyQuizzes from "@/components/user/learning/MyQuizzes";
import MyMembership from "@/components/user/membership/MyMembership";
import MyMeditations from "@/components/user/learning/MyMeditations";
import Reviews from "@/components/user/learning/Reviews";
import AddressBook from "@/components/user/profile/AddressBook";
import BadgesPanel from "@/components/user/profile/BadgesPanel";

export default function DashboardPage({ section = "overview", segments = [] }) {
  const { role } = useWorkspace(); const id = segments[0];
  if (section === "overview") return <Overview />;
  if (role === "facilitator" && section === "profile") return <FacilitatorProfile />;
  if (section === "profile" || section === "settings") return <AccountSettings settings={section === "settings"} />;
  if (role === "facilitator") {
    if (section === "media") return <MediaLibrary />;
    if (section === "categories") return <FacilitatorCategories key={id || "list"} id={id} />;
    if (["curriculum", "students", "registrations", "reviews"].includes(section)) return <TeachingScope key={section} section={section} />;
    if (section === "analytics") return <Analytics />;
    if (section === "earnings") return <Earnings key={id || "list"} id={id} />;
    return <FacilitatorResources key={`${section}-${id || "list"}`} section={section} id={id} />;
  }
  if (section === "digital-library") return <div className="ws-embedded"><DigitalLibrary key={id || "list"} entitlementId={id} embedded /></div>;
  if (section === "application") return <ApplicationWizard />;
  if (section === "progress") return <LearningProgress />;
  if (section === "notifications") return <div className="ws-embedded"><MyNotifications /></div>;
  if (section === "community") return <div className="ws-embedded"><Questions key={id || "list"} questionId={id} /></div>;
  if (["orders", "payments", "refunds"].includes(section)) return <div className="ws-embedded"><CommerceCenter key={`${section}-${id || "list"}`} section={section} id={id} embedded /></div>;
  if (section === "addresses") return <div className="ws-embedded"><AddressBook /></div>;
  if (section === "badges") return <BadgesPanel />;
  if (section === "quizzes") return <div className="ws-embedded"><MyQuizzes key={segments.join("/")} quizId={id !== "attempts" ? id : undefined} attemptId={id === "attempts" ? segments[1] : undefined} /></div>;
  if (section === "membership") return <div className="ws-embedded"><MyMembership key={id || "list"} membershipId={id} /></div>;
  if (section === "meditations") return <div className="ws-embedded"><MyMeditations key={id || "list"} meditationId={id} /></div>;
  if (section === "reviews") return <div className="ws-embedded"><Reviews /></div>;
  if (section === "courses" && !id) return <MyCourses embedded />;
  if (id) return <div className="ws-embedded">{section === "courses" ? segments[1] === "lessons" && segments[2] ? <LessonSpace key={`${id}-${segments[2]}`} courseId={id} lessonId={segments[2]} /> : <CourseSpace key={id} courseId={id} /> : section === "workshops" ? <ClassSpace key={id} classId={id} /> : section === "bookings" ? <MySessions key={id} bookingId={id} /> : section === "orders" ? <CommerceCenter section="orders" id={id} /> : <CertificateDetail id={id} />}</div>;
  return <UserResources key={section} section={section} />;
}

import { useApi, date } from "./data";
import { Card, Badge } from "./Elements";
function CertificateDetail({ id }) { const state = useApi(`me/certificates/${id}`); const data = state.data?.certificate || state.data; return <><State {...state} retry={state.reload} />{data && <Card title={data.title || data.courseTitle || "Your certificate"}><Badge status={data.status} /><p className="ws-muted">Issued {date(data.issuedAt)}</p><p>{data.verificationCode || data.code}</p><a href={`/api/account/me/certificates/${id}/download`} className="ws-button">Download certificate</a></Card>}</>; }
