"use client";

import { useState } from "react";

function youtubeEmbedUrl(value) {
  if (!value) return null;
  try {
    const url = new URL(value);
    const host = url.hostname.toLowerCase().replace(/^www\./, "");
    let id = "";
    if (host === "youtu.be") id = url.pathname.slice(1).split("/")[0];
    if (host === "youtube.com" || host === "m.youtube.com" || host === "youtube-nocookie.com") {
      if (url.pathname === "/watch") id = url.searchParams.get("v") || "";
      else if (url.pathname.startsWith("/embed/")) id = url.pathname.split("/")[2] || "";
      else if (url.pathname.startsWith("/shorts/")) id = url.pathname.split("/")[2] || "";
    }
    return /^[A-Za-z0-9_-]{6,}$/.test(id) ? `https://www.youtube-nocookie.com/embed/${id}?rel=0&autoplay=1` : null;
  } catch {
    return null;
  }
}

function youtubeThumbnail(value) {
  const embed = youtubeEmbedUrl(value);
  const id = embed?.match(/embed\/([^?]+)/)?.[1];
  return id ? `https://i.ytimg.com/vi/${id}/hqdefault.jpg` : null;
}

export default function InlineVideoPreview({ src, poster, title, alt = "Meheck Mukherjee" }) {
  const [playing, setPlaying] = useState(false);
  const [thumbnailFailed, setThumbnailFailed] = useState(false);
  const embedUrl = youtubeEmbedUrl(src);
  const thumbnail = poster || youtubeThumbnail(src);
  const thumbnailSource = thumbnailFailed ? youtubeThumbnail(src) || "" : thumbnail;
  const isDirectVideo = Boolean(src && !embedUrl);
  const playable = Boolean(embedUrl || isDirectVideo);

  if (playing && embedUrl) {
    return <div className="relative h-full min-h-[420px] w-full overflow-hidden bg-black"><iframe className="absolute inset-0 h-full w-full" src={embedUrl} title={title} allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowFullScreen /></div>;
  }

  if (playing && isDirectVideo) {
    return <div className="relative h-full min-h-[420px] w-full overflow-hidden bg-black"><video className="h-full w-full object-contain" src={src} controls autoPlay playsInline /></div>;
  }

  return <div className="relative h-full min-h-[420px] w-full overflow-hidden bg-[#dfe8dc]">
    {thumbnailSource ? <img src={thumbnailSource} alt={alt} className="h-full w-full object-cover object-center" loading="eager" referrerPolicy="no-referrer" onError={() => setThumbnailFailed(true)} /> : <div className="h-full w-full bg-[#dfe8dc]" />}
    {playable ? <button type="button" onClick={() => setPlaying(true)} className="group absolute inset-0 grid place-items-center" aria-label={`Play ${title}`}>
      <span className="grid h-16 w-16 place-items-center rounded-full bg-white/90 text-[#29473c] shadow-[0_8px_25px_rgba(31,46,35,.25)] transition-transform group-hover:scale-110"><span className="ml-1 block h-0 w-0 border-y-[10px] border-l-[15px] border-y-transparent border-l-[#29473c]" /></span>
    </button> : null}
  </div>;
}
