﻿
"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";

import { accountFetch } from "@/lib/client-account";
import {
  dataOf,
  externalUrl,
  titleOf,
} from "@/lib/learning-data";

import {
  completedLesson,
  courseProgress,
} from "@/lib/course-learning";

const primary =
  "inline-flex min-h-11 items-center justify-center rounded-xl bg-[#28533d] px-5 text-sm font-semibold text-white transition hover:bg-[#1d3e2e] disabled:cursor-not-allowed disabled:opacity-50";

const secondary =
  "inline-flex min-h-11 items-center justify-center rounded-xl bg-[#edf4ec] px-5 text-sm font-semibold text-[#28533d] transition hover:bg-[#e3eee2] disabled:cursor-not-allowed disabled:opacity-50";

export default function LessonSpace({
  courseId,
  lessonId,
}) {
  const pathname = usePathname();

  const base = pathname.startsWith("/dashboard/")
    ? "/dashboard/user/courses"
    : "/profile/courses";

  const courseHref = `${base}/${encodeURIComponent(courseId)}`;

  const path = `me/courses/${encodeURIComponent(
    courseId
  )}/lessons/${encodeURIComponent(lessonId)}`;

  const progressPath = `me/courses/${encodeURIComponent(
    courseId
  )}/progress`;

  const seq = useRef(0);
  const lock = useRef(false);

  const [lesson, setLesson] = useState(null);
  const [progress, setProgress] = useState(null);
  const [completionResult, setCompletionResult] = useState(null);
  const [savedComplete, setSavedComplete] = useState(false);

  const [loading, setLoading] = useState(true);
  const [working, setWorking] = useState("");

  const [link, setLink] = useState("");
  const [expiresAt, setExpiresAt] = useState(0);
  const [expired, setExpired] = useState(false);

  const [error, setError] = useState("");
  const [errorStatus, setErrorStatus] = useState(null);
  const [progressError, setProgressError] = useState("");
  const [notice, setNotice] = useState("");

  const [question, setQuestion] = useState("");
  const [showQuestion, setShowQuestion] = useState(false);

  const load = useCallback(async () => {
    const current = ++seq.current;

    setLoading(true);
    setError("");
    setErrorStatus(null);
    setProgressError("");

    const [detail, progressResponse] =
      await Promise.allSettled([
        accountFetch(path),
        accountFetch(progressPath),
      ]);

    if (current !== seq.current) return;

    if (detail.status === "fulfilled") {
      const value = dataOf(detail.value);
      setLesson(value?.lesson || value);
    } else {
      setLesson(null);

      setError(
        detail.reason?.message || "Lesson is unavailable."
      );

      setErrorStatus(detail.reason?.status ?? null);
    }

    if (progressResponse.status === "fulfilled") {
      setProgress(dataOf(progressResponse.value));
    } else {
      setProgressError(
        progressResponse.reason?.message ||
          "Progress is unavailable."
      );
    }

    setLoading(false);
  }, [path, progressPath]);

  useEffect(() => {
    setLink("");
    setExpiresAt(0);
    setExpired(false);
    setSavedComplete(false);
    setCompletionResult(null);

    void load();

    return () => {
      seq.current += 1;
    };
  }, [load]);

  useEffect(() => {
    if (!expiresAt) return;

    const timeout = setTimeout(
      () => setExpired(true),
      Math.max(0, expiresAt - Date.now())
    );

    return () => clearTimeout(timeout);
  }, [expiresAt]);

  async function perform(name, run) {
    if (lock.current) return;

    lock.current = true;
    setWorking(name);
    setError("");
    setNotice("");

    try {
      await run();
    } catch (e) {
      setError(
        e?.message || "Action failed. Please try again."
      );
    } finally {
      lock.current = false;
      setWorking("");
    }
  }

  async function refreshProgress() {
    const token = seq.current;

    setProgressError("");

    try {
      const response = await accountFetch(progressPath);

      if (token === seq.current) {
        setProgress(dataOf(response));
      }
    } catch (e) {
      if (token === seq.current) {
        setProgressError(
          e?.message || "Progress could not be loaded."
        );
      }
    }
  }

  async function loadResource() {
    await perform("access", async () => {
      const token = seq.current;

      const response = await accountFetch(
        `${path}/access-link`,
        {
          method: "POST",
          body: {},
        }
      );

      const value = dataOf(response);

      const url =
        externalUrl(value) ||
        externalUrl(value?.accessLink);

      if (!url) {
        throw new Error(
          "The service did not provide a resource link."
        );
      }

      if (token !== seq.current) return;

      setLink(url);
      setExpired(false);

      const lifetime = Number(value?.expiresIn);

      setExpiresAt(
        Number.isFinite(lifetime) && lifetime > 0
          ? Date.now() + lifetime * 1000
          : 0
      );
    });
  }

  const completed =
    savedComplete ||
    completedLesson(progress, lessonId) ||
    lesson?.progress?.status === "COMPLETED";

  async function markComplete() {
    if (completed) return;

    await perform("complete", async () => {
      const token = seq.current;

      const response = await accountFetch(
        `${path}/progress`,
        {
          method: "POST",
          body: {
            status: "COMPLETED",
          },
        }
      );

      if (token !== seq.current) return;

      const value = dataOf(response);

      setSavedComplete(true);
      setCompletionResult(value);

      setNotice(
        value?.completed
          ? "Course completed. Well done!"
          : "Lesson marked as complete."
      );

      await refreshProgress();
    });
  }

  async function askQuestion(e) {
    e.preventDefault();

    if (question.trim().length < 5) return;

    await perform("question", async () => {
      await accountFetch(`${path}/questions`, {
        method: "POST",
        body: {
          body: question.trim(),
        },
      });

      setQuestion("");
      setShowQuestion(false);

      setNotice(
        "Your question was sent to the facilitator."
      );
    });
  }

  const kind = String(
    lesson?.contentType || ""
  ).toUpperCase();

  const externalMedia = [
    lesson?.videoUrl,
    lesson?.audioUrl,
    lesson?.documentUrl,
  ].find(
    (v) =>
      typeof v === "string" &&
      /^https?:\/\//i.test(v)
  );

  const hasUpload = Boolean(
    lesson?.fileAccessPath ||
      lesson?.videoSource === "UPLOAD" ||
      lesson?.videoMediaId ||
      lesson?.audioMediaId ||
      lesson?.documentMediaId ||
      lesson?.mediaId
  );

  const fileLesson =
    hasUpload ||
    (["VIDEO", "AUDIO", "DOCUMENT"].includes(kind) &&
      !externalMedia);

  const resourceUrl = link && !expired ? link : "";

  const values = courseProgress(
    progress || completionResult || lesson
  );

  const numericPercent = Number(values.percent);

  const percent =
    values.percent != null &&
    Number.isFinite(numericPercent)
      ? Math.min(100, Math.max(0, numericPercent))
      : null;

  const body =
    lesson?.content ||
    lesson?.description ||
    lesson?.text;

  return (
    <main className="min-h-[65vh] bg-white px-5 pb-20 pt-8 text-[#253d2e] sm:px-8">
      <div className="mx-auto max-w-6xl">
        <Link
          prefetch={false}
          href={courseHref}
          className="text-sm font-medium text-[#557361] hover:underline"
        >
          ← Back to course
        </Link>

        {loading ? (
          <div
            role="status"
            className="mt-8 animate-pulse space-y-4"
          >
            <div className="h-9 w-2/3 rounded bg-[#eff4ee]" />
            <div className="aspect-video max-w-3xl rounded-2xl bg-[#eff4ee]" />
            <span className="sr-only">
              Loading lesson
            </span>
          </div>
        ) : (
          <>
            {/* Lesson Header */}
            {lesson && (
              <header className="mt-7">
                <p className="text-xs font-semibold uppercase tracking-[.15em] text-[#7c927f]">
                  {lesson.sectionTitle || "Course lesson"}
                </p>

                <h1 className="mt-2 font-[Georgia,serif] text-3xl leading-tight sm:text-4xl">
                  {titleOf(lesson, "Lesson")}
                </h1>

                <div className="mt-3 flex flex-wrap gap-3 text-xs text-[#7d8e80]">
                  {kind && <span>{kind}</span>}

                  {lesson.duration > 0 && (
                    <span>
                      Duration: {lesson.duration}
                    </span>
                  )}

                  {completed && (
                    <span className="font-semibold text-[#2e7550]">
                      ✓ Completed
                    </span>
                  )}
                </div>
              </header>
            )}

            {error && (
              <p
                role="alert"
                className="mt-6 rounded-xl bg-[#fff4ef] px-4 py-3 text-sm text-[#97513d]"
              >
                {error}

                {!lesson && errorStatus === 401 && (
                  <Link
                    href={`/auth/login?next=${encodeURIComponent(
                      pathname
                    )}`}
                    className="ml-2 font-semibold underline"
                  >
                    Sign in
                  </Link>
                )}

                {!lesson && (
                  <button
                    type="button"
                    onClick={() => void load()}
                    className="ml-2 font-semibold underline"
                  >
                    Retry
                  </button>
                )}
              </p>
            )}

            {notice && (
              <p
                role="status"
                className="mt-6 rounded-xl bg-[#edf7ef] px-4 py-3 text-sm text-[#2f724a]"
              >
                {notice}
              </p>
            )}

            {lesson && (
              <div className="mt-7 grid items-start gap-10 lg:grid-cols-[minmax(0,1fr)_260px] lg:gap-12">
                <article className="min-w-0 space-y-8">

                  {/* Protected Lesson Resource */}
                  {fileLesson && (
                    <section aria-label="Lesson media">
                      <div className="overflow-hidden rounded-2xl bg-[#f3f6f2]">
                        {resourceUrl && kind === "VIDEO" ? (
                          <video
                            key={resourceUrl}
                            src={resourceUrl}
                            controls
                            playsInline
                            preload="metadata"
                            className="aspect-video w-full bg-black"
                            onError={() => {
                              setLink("");
                              setError(
                                "Video playback failed. Refresh resource access and try again."
                              );
                            }}
                          >
                            Your browser does not support
                            video playback.
                          </video>
                        ) : resourceUrl &&
                          kind === "AUDIO" ? (
                          <div className="p-5 sm:p-8">
                            <p className="mb-4 text-sm font-medium text-[#3f624a]">
                              Audio lesson
                            </p>

                            <audio
                              key={resourceUrl}
                              src={resourceUrl}
                              controls
                              preload="metadata"
                              className="w-full"
                              onError={() => {
                                setLink("");
                                setError(
                                  "Audio could not be played. Refresh resource access."
                                );
                              }}
                            />
                          </div>
                        ) : (
                          <div className="flex min-h-44 flex-col items-center justify-center gap-3 px-5 py-8 text-center sm:min-h-64">
                            <span
                              className="flex size-14 items-center justify-center rounded-full bg-[#e5efe4] text-2xl text-[#366b4a]"
                              aria-hidden="true"
                            >
                              {kind === "VIDEO"
                                ? "▶"
                                : kind === "AUDIO"
                                ? "♫"
                                : "↗"}
                            </span>

                            <p className="text-sm text-[#68806c]">
                              {expired
                                ? "Your resource link expired. Renew access to continue."
                                : "Open your lesson resource when you are ready."}
                            </p>

                            <button
                              type="button"
                              onClick={loadResource}
                              disabled={Boolean(working)}
                              className={primary}
                            >
                              {working === "access"
                                ? "Loading…"
                                : expired || link
                                ? "Renew resource access"
                                : kind === "VIDEO"
                                ? "Load lesson video"
                                : kind === "AUDIO"
                                ? "Load lesson audio"
                                : "Open lesson resource"}
                            </button>
                          </div>
                        )}
                      </div>

                      {resourceUrl && (
                        <div className="mt-3 flex flex-wrap gap-x-5 gap-y-2">
                          <a
                            href={resourceUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm font-semibold text-[#2d6447] hover:underline"
                          >
                            Open resource in new tab ↗
                          </a>

                          <button
                            type="button"
                            onClick={loadResource}
                            disabled={Boolean(working)}
                            className="text-sm text-[#67816c] hover:underline"
                          >
                            Refresh access
                          </button>
                        </div>
                      )}
                    </section>
                  )}

                  {/* External Media */}
                  {!fileLesson && externalMedia && (
                    <a
                      href={externalMedia}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={primary}
                    >
                      Open lesson resource ↗
                    </a>
                  )}

                  {/* Lesson Notes */}
                  {body && (
                    <section>
                      <h2 className="text-lg font-semibold">
                        Lesson notes
                      </h2>

                      <div className="mt-3 whitespace-pre-line text-sm leading-8 text-[#607363]">
                        {body}
                      </div>
                    </section>
                  )}

                  {/* Connected Learning Resources */}
                  {(lesson.quizId || lesson.classId) && (
                    <div className="flex flex-wrap gap-3">
                      {lesson.quizId && (
                        <Link
                          prefetch={false}
                          href={`/profile/quizzes/${encodeURIComponent(
                            lesson.quizId
                          )}`}
                          className={secondary}
                        >
                          Open quiz ↗
                        </Link>
                      )}

                      {lesson.classId && (
                        <Link
                          prefetch={false}
                          href={`/profile/classes/${encodeURIComponent(
                            lesson.classId
                          )}`}
                          className={secondary}
                        >
                          Open linked class ↗
                        </Link>
                      )}
                    </div>
                  )}

                  {/* Facilitator Questions */}
                  <section className="pt-1">
                    <button
                      type="button"
                      onClick={() =>
                        setShowQuestion((v) => !v)
                      }
                      className="text-sm font-semibold text-[#2d6447] hover:underline"
                    >
                      {showQuestion
                        ? "Close question form"
                        : "Ask the facilitator →"}
                    </button>

                    {showQuestion && (
                      <form
                        onSubmit={askQuestion}
                        className="mt-4 rounded-xl bg-[#f7faf6] p-5"
                      >
                        <label className="block text-sm font-medium">
                          Your question

                          <textarea
                            required
                            minLength={5}
                            maxLength={2000}
                            rows={4}
                            value={question}
                            onChange={(e) =>
                              setQuestion(e.target.value)
                            }
                            placeholder="What would you like to ask?"
                            className="mt-2 w-full rounded-xl border border-[#dfe8df] bg-white px-4 py-3 text-sm outline-none focus:border-[#719d7b]"
                          />
                        </label>

                        <div className="mt-4 flex flex-wrap items-center gap-4">
                          <button
                            type="submit"
                            className={primary}
                            disabled={
                              Boolean(working) ||
                              question.trim().length < 5
                            }
                          >
                            {working === "question"
                              ? "Sending…"
                              : "Send question"}
                          </button>

                          <Link
                            href="/profile/questions"
                            className="text-sm font-medium text-[#2d6447] hover:underline"
                          >
                            My questions
                          </Link>
                        </div>
                      </form>
                    )}
                  </section>
                </article>

                {/* Course Progress Sidebar */}
                <aside className="rounded-2xl bg-[#f5f8f3] p-5 lg:sticky lg:top-24">
                  <div className="flex items-center justify-between gap-3">
                    <h2 className="text-base font-semibold">
                      Your progress
                    </h2>

                    {percent != null && (
                      <span className="text-sm font-semibold text-[#2c6648]">
                        {Math.round(percent)}%
                      </span>
                    )}
                  </div>

                  {percent != null && (
                    <div
                      role="progressbar"
                      aria-label="Course progress"
                      aria-valuemin={0}
                      aria-valuemax={100}
                      aria-valuenow={percent}
                      className="mt-4 h-2 overflow-hidden rounded-full bg-[#e0eadf]"
                    >
                      <div
                        style={{
                          width: `${percent}%`,
                        }}
                        className="h-full rounded-full bg-[#477b56]"
                      />
                    </div>
                  )}

                  {values.completed != null &&
                    values.total != null && (
                      <p className="mt-3 text-xs leading-5 text-[#728475]">
                        {values.completed} of {values.total}{" "}
                        lessons completed
                      </p>
                    )}

                  {progressError && (
                    <div
                      role="alert"
                      className="mt-3 text-xs leading-5 text-[#965141]"
                    >
                      {progressError}

                      <button
                        type="button"
                        onClick={() =>
                          void refreshProgress()
                        }
                        className="ml-2 font-semibold underline"
                      >
                        Retry
                      </button>
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={markComplete}
                    disabled={
                      Boolean(working) || completed
                    }
                    className={`${primary} mt-5 w-full`}
                  >
                    {completed
                      ? "✓ Lesson completed"
                      : working === "complete"
                      ? "Saving…"
                      : "Mark as complete"}
                  </button>

                  <Link
                    prefetch={false}
                    href={courseHref}
                    className="mt-3 inline-flex w-full items-center justify-center py-2 text-sm font-semibold text-[#2d6447] hover:underline"
                  >
                    {completionResult?.completed
                      ? "View completed course"
                      : "All course lessons"}{" "}
                    →
                  </Link>
                </aside>
              </div>
            )}
          </>
        )}
      </div>
    </main>
  );
}
