
"use client";

import Link from "next/link";
import { useState } from "react";
import { RecordMedia } from "@/components/common/ApiRecordDisplay";
import { useApi, rowsOf } from "@/components/common/dashboard/data";
import {
  enrolledCourseId,
  courseLearningHref,
  courseProgress,
} from "@/lib/course-learning";

/* -------------------- ICONS -------------------- */

function SearchIcon() {
  return (
    <svg
      width="18"
      height="18"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <circle cx="11" cy="11" r="7" />
      <path d="m20 20-4-4" />
    </svg>
  );
}

function ArrowIcon() {
  return (
    <svg
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M5 12h14m-7-7 7 7-7 7" />
    </svg>
  );
}

function BookIcon({ size = 27 }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
      <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z" />
    </svg>
  );
}

function PlayIcon() {
  return (
    <svg
      width="15"
      height="15"
      viewBox="0 0 24 24"
      fill="currentColor"
      aria-hidden="true"
    >
      <path d="m8 5 12 7-12 7V5Z" />
    </svg>
  );
}

/* -------------------- HELPERS -------------------- */

function getCourseInfo(record, base) {
  const course =
    record.course && typeof record.course === "object"
      ? record.course
      : {};

  // Keep enrollment fields separate from course metadata.
  const item = { ...record, ...course };

  const rawStatus = String(
    record.enrollmentStatus ||
      record.enrollment?.status ||
      record.status ||
      "ENROLLED"
  ).toUpperCase();

  const progressData = courseProgress(record) || {};

  const value = progressData.percent;

  const percent =
    value !== null &&
    value !== undefined &&
    value !== "" &&
    Number.isFinite(Number(value))
      ? Math.min(100, Math.max(0, Number(value)))
      : null;

  const completed =
    record.completed === true ||
    record.enrollment?.completed === true ||
    rawStatus === "COMPLETED";

  const cancelled = ["CANCELLED", "CANCELED"].includes(
    rawStatus
  );

  const expired = rawStatus === "EXPIRED";

  const unavailable =
    record.hasAccess === false || cancelled || expired;

  let status = "Not started";
  let statusType = "neutral";

  if (completed) {
    status = "Completed";
    statusType = "success";
  } else if (cancelled) {
    status = "Cancelled";
    statusType = "danger";
  } else if (expired) {
    status = "Expired";
    statusType = "danger";
  } else if (record.hasAccess === false) {
    status = "Access unavailable";
    statusType = "danger";
  } else if (percent !== null && percent > 0) {
    status = "In progress";
    statusType = "active";
  } else if (rawStatus === "ACTIVE" || rawStatus === "IN_PROGRESS") {
    status = "In progress";
    statusType = "active";
  }

  const imageAvailable = Boolean(
    item.thumbnail ||
      item.thumbnailMediaId ||
      item.image ||
      item.imageMediaId ||
      item.featuredImage ||
      item.banner ||
      item.bannerMediaId ||
      (Array.isArray(item.images) && item.images.length)
  );

  const certificateId =
    record.certificateId || record.certificate?.id;

  return {
    item,
    id: enrolledCourseId(record),
    title: course.title || record.title || "Course",
    facilitator:
      course.facilitatorName ||
      record.facilitatorName ||
      course.facilitator?.name ||
      record.facilitator?.name ||
      "",
    percent,
    completedLessons: progressData.completed,
    totalLessons: progressData.total,
    completed,
    unavailable,
    status,
    statusType,
    imageAvailable,
    certificateId,
    certificateAvailable: Boolean(
      record.certificateAvailable && certificateId
    ),
    href: courseLearningHref(record, base),
  };
}

/* -------------------- STATUS -------------------- */

function Status({ label, type }) {
  const styles = {
    success: "bg-[#edf6ee] text-[#35724b]",
    active: "bg-[#edf4ef] text-[#416c52]",
    danger: "bg-[#fff0ed] text-[#b65a4d]",
    neutral: "bg-[#f2f4f1] text-[#718076]",
  };

  return (
    <span
      className={`inline-flex w-fit items-center rounded-md px-2.5 py-1 text-[11px] font-semibold ${
        styles[type] || styles.neutral
      }`}
    >
      {label}
    </span>
  );
}

/* -------------------- IMAGE -------------------- */

function CourseImage({ info }) {
  return (
    <div className="relative aspect-[16/10] w-full shrink-0 overflow-hidden rounded-lg bg-[#f0f3ee] sm:w-[180px] lg:w-[192px]">
      {info.imageAvailable ? (
        <div className="h-full w-full overflow-hidden [&_img]:!h-full [&_img]:!w-full [&_img]:!object-cover [&_picture]:!block [&_picture]:!h-full [&_picture]:!w-full">
          <RecordMedia
            record={info.item}
            compact
            imagesOnly
          />
        </div>
      ) : (
        <div className="flex h-full w-full flex-col items-center justify-center gap-2 text-[#8ba194]">
          <BookIcon size={34} />
          <span className="text-[11px] font-medium">
            Course
          </span>
        </div>
      )}
    </div>
  );
}

/* -------------------- PROGRESS -------------------- */

function CourseProgress({ info }) {
  const hasPercent = info.percent !== null;

  const hasLessonCount =
    info.completedLessons != null &&
    info.totalLessons != null;

  if (!hasPercent && !hasLessonCount) {
    return null;
  }

  return (
    <div className="mt-4 max-w-[430px]">
      <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
        <span className="text-[12px] font-medium text-[#6a7b70]">
          Course progress
        </span>

        {hasPercent && (
          <span className="text-[12px] font-semibold tabular-nums text-[#345b45]">
            {Math.round(info.percent)}%
          </span>
        )}
      </div>

      {hasPercent && (
        <div
          role="progressbar"
          aria-label={`${info.title} progress`}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={info.percent}
          className="h-[6px] w-full overflow-hidden rounded-full bg-[#e9efea]"
        >
          <div
            className="h-full rounded-full bg-[#47735a] transition-all duration-500"
            style={{ width: `${info.percent}%` }}
          />
        </div>
      )}

      {hasLessonCount && (
        <p className="mt-2 text-[12px] text-[#89948c]">
          {info.completedLessons} of {info.totalLessons} lessons completed
        </p>
      )}
    </div>
  );
}

/* -------------------- COURSE ITEM -------------------- */

function CourseItem({ record, base }) {
  const info = getCourseInfo(record, base);

  const actionText = info.unavailable
    ? "View access details"
    : info.completed
    ? "Review course"
    : info.percent !== null && info.percent > 0
    ? "Continue learning"
    : "Start learning";

  return (
    <article className="flex flex-col gap-4 border-b border-[#edf0ec] py-6 first:pt-0 last:border-b-0 sm:flex-row sm:gap-5">
      <CourseImage info={info} />

      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex flex-wrap items-center gap-2">
          <Status
            label={info.status}
            type={info.statusType}
          />
        </div>

        <h3 className="mt-3 break-words text-[17px] font-semibold leading-[1.45] tracking-[-0.3px] text-[#263b2e] sm:text-[18px]">
          {info.title}
        </h3>

        {info.facilitator && (
          <p className="mt-1.5 text-[12px] text-[#819085]">
            By {info.facilitator}
          </p>
        )}

        <CourseProgress info={info} />

        {info.unavailable && (
          <p className="mt-3 text-[12px] text-[#a35c4d]">
            Learning access is currently unavailable.
          </p>
        )}

        <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-3">
          {info.href && (
            <Link
              prefetch={false}
              href={info.href}
              className="inline-flex min-h-10 items-center justify-center gap-2 rounded-lg bg-[#315a48] px-4 text-[12px] font-semibold text-white transition-colors hover:bg-[#244535]"
            >
              {!info.unavailable && !info.completed && (
                <PlayIcon />
              )}

              {actionText}

              <ArrowIcon />
            </Link>
          )}

          {info.certificateAvailable && (
            <Link
              prefetch={false}
              href={`/profile/certificates/${encodeURIComponent(
                info.certificateId
              )}`}
              className="text-[12px] font-semibold text-[#315a48] underline-offset-4 hover:underline"
            >
              View certificate
            </Link>
          )}
        </div>
      </div>
    </article>
  );
}

/* -------------------- LOADING -------------------- */

function CourseSkeleton() {
  return (
    <div
      aria-hidden="true"
      className="animate-pulse space-y-0"
    >
      {[1, 2, 3].map((item) => (
        <div
          key={item}
          className="flex gap-5 border-b border-[#edf0ec] py-6 first:pt-0"
        >
          <div className="h-[110px] w-[160px] shrink-0 rounded-lg bg-[#f0f2ef] max-sm:w-[110px]" />

          <div className="flex-1 space-y-3">
            <div className="h-5 w-20 rounded bg-[#edf0ec]" />
            <div className="h-5 w-3/4 rounded bg-[#edf0ec]" />
            <div className="h-3 w-1/3 rounded bg-[#edf0ec]" />
            <div className="mt-3 h-2 w-2/3 rounded bg-[#edf0ec]" />
          </div>
        </div>
      ))}
    </div>
  );
}

/* -------------------- EMPTY STATE -------------------- */

function EmptyCourses({ filtered, onClear }) {
  return (
    <div className="flex min-h-[285px] flex-col items-center justify-center px-4 py-10 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-full bg-[#f0f5f0] text-[#688873]">
        {filtered ? <SearchIcon /> : <BookIcon />}
      </div>

      <h3 className="mt-4 text-[17px] font-semibold text-[#304737]">
        {filtered
          ? "No matching courses"
          : "Your learning journey starts here"}
      </h3>

      <p className="mt-2 max-w-sm text-[13px] leading-6 text-[#849287]">
        {filtered
          ? "Try a different search or filter to find your course."
          : "Courses you enroll in will appear here, ready for you to learn."}
      </p>

      {filtered ? (
        <button
          type="button"
          onClick={onClear}
          className="mt-5 rounded-lg border border-[#d5dfd6] px-5 py-2.5 text-[13px] font-semibold text-[#315a48] hover:bg-[#f7faf7]"
        >
          Clear filters
        </button>
      ) : (
        <Link
          href="/courses"
          className="mt-5 inline-flex items-center gap-2 rounded-lg bg-[#315a48] px-5 py-2.5 text-[13px] font-semibold text-white hover:bg-[#244535]"
        >
          Explore courses
          <ArrowIcon />
        </Link>
      )}
    </div>
  );
}

/* -------------------- MAIN PAGE -------------------- */

export default function MyCourses({ embedded = false }) {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");

  const state = useApi(
    `me/courses?page=${page}&limit=20`
  );

  const records = rowsOf(state.data, [
    "courses",
    "enrollments",
  ]);

  const base = embedded
    ? "/dashboard/user/courses"
    : "/profile/courses";

  const courseRows = records.map((record) => ({
    record,
    info: getCourseInfo(record, base),
  }));

  const normalizedSearch = search.trim().toLowerCase();

  const shown = courseRows.filter(({ info }) => {
    const text = `${info.title} ${info.facilitator}`.toLowerCase();

    const matchesSearch =
      !normalizedSearch || text.includes(normalizedSearch);

    let matchesFilter = true;

    if (filter === "ongoing") {
      matchesFilter =
        !info.completed && !info.unavailable;
    }

    if (filter === "completed") {
      matchesFilter = info.completed;
    }

    return matchesSearch && matchesFilter;
  });

  const pages = Math.max(
    1,
    Number(
      state.pagination?.pages ||
        state.pagination?.totalPages ||
        1
    )
  );

  const errorMessage =
    typeof state.error === "string"
      ? state.error
      : state.error?.message;

  const filters = [
    { id: "all", title: "All courses" },
    { id: "ongoing", title: "Ongoing" },
    { id: "completed", title: "Completed" },
  ];

  function clearFilters() {
    setSearch("");
    setFilter("all");
  }

  function changePage(nextPage) {
    if (
      nextPage < 1 ||
      nextPage > pages ||
      state.loading
    ) {
      return;
    }

    setPage(nextPage);
    setSearch("");
  }

  const isInitialLoading =
    state.loading && !records.length;

  return (
    <section
      aria-label="My enrolled courses"
      className={
        embedded
          ? "w-full bg-white text-[#29473c]"
          : "min-h-[70vh] bg-white px-4 pb-14 pt-6 text-[#29473c] sm:px-6 lg:px-8"
      }
    >
      <div className="mx-auto w-full max-w-5xl">
        {/* Page heading */}
        {!embedded && (
          <div className="mb-7 flex flex-wrap items-center justify-between gap-4">
            <div>
              <h1 className="text-[26px] font-semibold tracking-[-0.7px] text-[#263b2e] sm:text-[30px]">
                My Courses
              </h1>

              <p className="mt-1.5 text-[13px] leading-6 text-[#829087]">
                Pick up where you left off and keep learning.
              </p>
            </div>

            <Link
              href="/courses"
              className="inline-flex min-h-10 items-center gap-2 rounded-lg border border-[#d8e2da] bg-white px-4 text-[13px] font-semibold text-[#315a48] transition hover:bg-[#f6f9f6]"
            >
              Browse courses
              <ArrowIcon />
            </Link>
          </div>
        )}

        {/* Search */}
        <div className="mb-5">
          <div className="relative">
            <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-[#85958a]">
              <SearchIcon />
            </span>

            <input
              type="search"
              aria-label="Search courses on current page"
              placeholder="Search your courses..."
              value={search}
              onChange={(event) =>
                setSearch(event.target.value)
              }
              className="h-11 w-full rounded-lg border border-[#dce4dd] bg-white pl-11 pr-4 text-[13px] text-[#2c4233] outline-none transition placeholder:text-[#9ba9a0] focus:border-[#648a70] focus:ring-2 focus:ring-[#315a48]/10"
            />
          </div>
        </div>

        {/* Filters */}
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3 border-b border-[#e8ede8]">
          <div className="flex min-w-0 items-center gap-6 overflow-x-auto">
            {filters.map((option) => {
              const active = filter === option.id;

              return (
                <button
                  key={option.id}
                  type="button"
                  onClick={() => setFilter(option.id)}
                  aria-pressed={active}
                  className={`relative shrink-0 whitespace-nowrap pb-3 text-[13px] font-medium transition ${
                    active
                      ? "font-semibold text-[#315a48]"
                      : "text-[#89968b] hover:text-[#315a48]"
                  }`}
                >
                  {option.title}

                  {active && (
                    <span className="absolute inset-x-0 bottom-0 h-[2px] rounded-full bg-[#315a48]" />
                  )}
                </button>
              );
            })}
          </div>

          {!isInitialLoading && !errorMessage && (
            <p className="pb-3 text-[12px] text-[#8a988e]">
              {shown.length} shown
            </p>
          )}
        </div>

        {/* Errors */}
        {errorMessage && (
          <div
            role="alert"
            className="rounded-lg border border-[#f3dcd6] bg-[#fff8f6] px-4 py-4 text-[13px] text-[#a15445]"
          >
            <p>{errorMessage}</p>

            <div className="mt-3 flex items-center gap-4">
              <button
                type="button"
                onClick={() => state.reload()}
                disabled={state.loading}
                className="font-semibold underline underline-offset-4 disabled:opacity-50"
              >
                Try again
              </button>

              {state.status === 401 && (
                <Link
                  href="/auth/login"
                  className="font-semibold underline underline-offset-4"
                >
                  Sign in
                </Link>
              )}
            </div>
          </div>
        )}

        {/* Loading */}
        {isInitialLoading && !errorMessage && (
          <div role="status" aria-label="Loading courses">
            <CourseSkeleton />
            <span className="sr-only">
              Loading enrolled courses...
            </span>
          </div>
        )}

        {/* Courses */}
        {!state.loading && !errorMessage && (
          <>
            {shown.length ? (
              <div className="w-full">
                {shown.map(({ record, info }, index) => (
                  <CourseItem
                    key={
                      record.enrollment?.id ||
                      record.enrollmentId ||
                      record.id ||
                      info.id ||
                      index
                    }
                    record={record}
                    base={base}
                  />
                ))}
              </div>
            ) : (
              <EmptyCourses
                filtered={Boolean(normalizedSearch || filter !== "all" || records.length)}
                onClear={clearFilters}
              />
            )}

            {/* Pagination */}
            {pages > 1 && (
              <nav
                aria-label="My courses pagination"
                className="mt-8 flex flex-wrap items-center justify-between gap-4 border-t border-[#edf0ec] pt-6"
              >
                <p className="text-[12px] text-[#829087]">
                  Page{" "}
                  <span className="font-semibold text-[#344d3c]">
                    {page}
                  </span>{" "}
                  of{" "}
                  <span className="font-semibold text-[#344d3c]">
                    {pages}
                  </span>
                </p>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    disabled={page <= 1 || state.loading}
                    onClick={() =>
                      changePage(page - 1)
                    }
                    className="rounded-lg border border-[#dfe6df] px-4 py-2.5 text-[12px] font-medium text-[#415849] transition hover:bg-[#f5f8f5] disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    Previous
                  </button>

                  <button
                    type="button"
                    disabled={page >= pages || state.loading}
                    onClick={() =>
                      changePage(page + 1)
                    }
                    className="rounded-lg border border-[#dfe6df] px-4 py-2.5 text-[12px] font-medium text-[#415849] transition hover:bg-[#f5f8f5] disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    Next
                  </button>
                </div>
              </nav>
            )}
          </>
        )}
      </div>
    </section>
  );
}
