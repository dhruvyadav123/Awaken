
"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";

import { RecordMedia } from "@/components/common/ApiRecordDisplay";
import { accountFetch } from "@/lib/client-account";
import { dataOf, lessonsOf, titleOf } from "@/lib/learning-data";
import {
  courseProgress,
  courseLearningHref,
  completedLesson,
} from "@/lib/course-learning";
import { recordMedia } from "@/lib/record-display";
import { MembershipDiscount } from "@/components/user/membership/MyMembership";
import { CourseReviewForm } from "./Reviews";

const primary =
  "inline-flex min-h-11 items-center justify-center rounded-xl bg-[#28533d] px-5 text-sm font-semibold text-white transition hover:bg-[#1d3e2e] disabled:cursor-not-allowed disabled:opacity-50";

const asStatus = (v) =>
  String(v || "").replaceAll("_", " ").toLowerCase();

const shortDate = (v) => {
  if (!v || Number.isNaN(new Date(v).getTime())) return "";

  return new Intl.DateTimeFormat("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  }).format(new Date(v));
};

export default function CourseSpace({ courseId }) {
  const pathname = usePathname();

  const base = pathname.startsWith("/dashboard/")
    ? "/dashboard/user/courses"
    : "/profile/courses";

  const seq = useRef(0);
  const enrollLock = useRef(false);

  const [course, setCourse] = useState(null);
  const [progress, setProgress] = useState(null);
  const [loading, setLoading] = useState(true);
  const [working, setWorking] = useState(false);
  const [error, setError] = useState("");
  const [status, setStatus] = useState(null);
  const [progressError, setProgressError] = useState("");
  const [notice, setNotice] = useState("");

  const path = `me/courses/${encodeURIComponent(courseId)}`;

  const load = useCallback(async () => {
    const token = ++seq.current;

    setLoading(true);
    setError("");
    setStatus(null);
    setProgressError("");

    try {
      const value = dataOf(await accountFetch(path));

      if (token !== seq.current) return;

      const record = value?.course
        ? {
            ...value.course,
            ...value,
            lessons: value.lessons || value.course.lessons,
            enrollmentStatus:
              value.enrollmentStatus ||
              value.enrollment?.status ||
              value.course.enrollmentStatus,
          }
        : value;

      setCourse(record);

      if (record?.hasAccess !== false) {
        try {
          const response = await accountFetch(
            `${path}/progress`
          );

          if (token === seq.current) {
            setProgress(dataOf(response));
          }
        } catch (e) {
          if (token === seq.current) {
            setProgressError(
              e?.message || "Progress could not be loaded."
            );
          }
        }
      } else if (token === seq.current) {
        setProgress(null);
      }
    } catch (e) {
      if (token === seq.current) {
        setCourse(null);
        setProgress(null);

        setError(
          e?.message || "Course details could not be loaded."
        );

        setStatus(e?.status ?? null);
      }
    } finally {
      if (token === seq.current) setLoading(false);
    }
  }, [path]);

  useEffect(() => {
    void load();

    return () => {
      seq.current += 1;
    };
  }, [load]);

  async function enroll() {
    if (enrollLock.current) return;

    enrollLock.current = true;
    setWorking(true);
    setError("");
    setNotice("");

    try {
      const response = await accountFetch(`${path}/enroll`, {
        method: "POST",
        body: {},
      });

      setNotice(
        response?.message || "Enrollment request accepted."
      );

      await load();
    } catch (e) {
      setError(
        e?.message || "Enrollment could not be completed."
      );

      setStatus(e?.status ?? null);
    } finally {
      enrollLock.current = false;
      setWorking(false);
    }
  }

  const canAccess =
    Boolean(course) && course?.hasAccess !== false;

  const enrollmentStatus =
    course?.enrollmentStatus || course?.enrollment?.status;

  const lessons = course ? lessonsOf(course) : [];

  const progressValues = courseProgress(progress || course);
  const percent = Number(progressValues.percent);

  const hasPercent =
    progressValues.percent != null &&
    Number.isFinite(percent);

  const safePercent = Math.min(100, Math.max(0, percent));

  const resume = course
    ? courseLearningHref(
        {
          ...course,
          courseId,
        },
        base
      )
    : "";

  const firstId =
    lessons[0]?.id || lessons[0]?.lessonId;

  const mainHref = `${base}/${encodeURIComponent(courseId)}`;

  const start =
    resume && resume !== mainHref
      ? resume
      : firstId
      ? `${mainHref}/lessons/${encodeURIComponent(firstId)}`
      : "";

  const hasCover =
    course &&
    recordMedia(course, { imagesOnly: true }).length > 0;

  const description =
    course?.shortDescription || course?.description;

  return (
    <main className="min-h-[65vh] bg-white px-5 pb-20 pt-8 text-[#253d2e] sm:px-8">
      <div className="mx-auto max-w-6xl">
        <Link
          prefetch={false}
          href={base}
          className="text-sm font-medium text-[#557361] hover:underline"
        >
          ← My courses
        </Link>

        {loading ? (
          <div
            role="status"
            className="mt-8 animate-pulse space-y-4"
          >
            <div className="h-10 w-2/3 rounded bg-[#eff4ee]" />
            <div className="h-44 rounded-2xl bg-[#eff4ee]" />
            <span className="sr-only">Loading course</span>
          </div>
        ) : (
          <>
            {course ? (
              <>
                {/* Course Header */}
                <header className="mt-7 grid items-center gap-7 lg:grid-cols-[1fr_340px]">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-[.16em] text-[#78907b]">
                      My learning
                    </p>

                    <h1 className="mt-2 font-[Georgia,serif] text-3xl leading-tight sm:text-4xl">
                      {titleOf(course, "Course learning space")}
                    </h1>

                    {description && (
                      <p className="mt-3 max-w-2xl text-sm leading-7 text-[#67796a]">
                        {description}
                      </p>
                    )}

                    <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-[#789082]">
                      {course.facilitatorName && (
                        <span>
                          By {course.facilitatorName}
                        </span>
                      )}

                      {enrollmentStatus && (
                        <span className="rounded-full bg-[#edf5ec] px-3 py-1.5 font-semibold text-[#356749]">
                          {asStatus(enrollmentStatus)}
                        </span>
                      )}

                      {shortDate(course.expiresAt) && (
                        <span>
                          Access until{" "}
                          {shortDate(course.expiresAt)}
                        </span>
                      )}
                    </div>
                  </div>

                  {hasCover && (
                    <div className="max-h-[220px] overflow-hidden rounded-2xl bg-[#eef4ee] [&_img]:max-h-[220px] [&_img]:w-full [&_img]:object-cover">
                      <RecordMedia
                        record={course}
                        imagesOnly
                        compact
                      />
                    </div>
                  )}
                </header>

                {notice && (
                  <p
                    role="status"
                    className="mt-6 rounded-xl bg-[#edf7ef] px-4 py-3 text-sm text-[#2b7047]"
                  >
                    {notice}
                  </p>
                )}

                {error && (
                  <p
                    role="alert"
                    className="mt-6 rounded-xl bg-[#fff3ef] px-4 py-3 text-sm text-[#984b3b]"
                  >
                    {error}
                  </p>
                )}

                {!canAccess && (
                  <p
                    role="status"
                    className="mt-6 rounded-xl bg-[#fff5ed] px-4 py-3 text-sm leading-6 text-[#94613b]"
                  >
                    Your lesson access is currently unavailable.{" "}
                    <Link
                      href="/contact"
                      className="font-semibold underline"
                    >
                      Contact support
                    </Link>{" "}
                    if you need help.
                  </p>
                )}

                {/* Main Learning Layout */}
                <div className="mt-9 grid items-start gap-10 lg:grid-cols-[minmax(0,1fr)_280px] lg:gap-12">
                  <section className="min-w-0">
                    <div className="flex flex-wrap items-end justify-between gap-3">
                      <div>
                        <h2 className="text-xl font-semibold">
                          Course lessons
                        </h2>

                        <p className="mt-1 text-sm text-[#7b8b7e]">
                          Pick up where you left off.
                        </p>
                      </div>

                      <span className="text-xs text-[#7f9082]">
                        {lessons.length}{" "}
                        {lessons.length === 1
                          ? "lesson"
                          : "lessons"}
                      </span>
                    </div>

                    {/* Lesson List */}
                    {lessons.length ? (
                      <ol className="mt-4 space-y-2.5">
                        {lessons.map((lesson, index) => {
                          const lessonId =
                            lesson.id || lesson.lessonId;

                          const complete = Boolean(
                            lessonId &&
                              completedLesson(
                                progress,
                                lessonId
                              )
                          );

                          const href = lessonId
                            ? `${mainHref}/lessons/${encodeURIComponent(
                                lessonId
                              )}`
                            : "";

                          return (
                            <li
                              key={
                                lessonId ||
                                `${lesson.title}-${index}`
                              }
                              className="flex items-center gap-3 rounded-xl bg-[#f7faf6] px-4 py-4 transition hover:bg-[#f0f6ee]"
                            >
                              <span
                                className={`flex size-9 shrink-0 items-center justify-center rounded-full text-xs font-semibold ${
                                  complete
                                    ? "bg-[#e1f0e4] text-[#2b7045]"
                                    : "bg-white text-[#7a8e7f]"
                                }`}
                              >
                                {complete
                                  ? "✓"
                                  : String(index + 1).padStart(
                                      2,
                                      "0"
                                    )}
                              </span>

                              <div className="min-w-0 flex-1">
                                <p className="text-[11px] text-[#829285]">
                                  {lesson.sectionTitle ||
                                    lesson.contentType ||
                                    "Lesson"}

                                  {complete
                                    ? " · Completed"
                                    : ""}
                                </p>

                                <h3 className="mt-1 text-sm font-semibold leading-6 text-[#294632]">
                                  {titleOf(
                                    lesson,
                                    `Lesson ${index + 1}`
                                  )}
                                </h3>
                              </div>

                              {canAccess && href && (
                                <Link
                                  prefetch={false}
                                  href={href}
                                  className="shrink-0 text-xs font-semibold text-[#2b6546] hover:underline"
                                >
                                  {complete
                                    ? "Review"
                                    : "Open"}{" "}
                                  →
                                </Link>
                              )}
                            </li>
                          );
                        })}
                      </ol>
                    ) : (
                      <p className="mt-5 text-sm text-[#768779]">
                        No lessons have been published yet.
                      </p>
                    )}

                    {/* Certificate */}
                    {course.certificateAvailable &&
                      course.certificateId && (
                        <Link
                          prefetch={false}
                          href={`/profile/certificates/${encodeURIComponent(
                            course.certificateId
                          )}`}
                          className="mt-6 inline-block text-sm font-semibold text-[#2b6546] hover:underline"
                        >
                          View certificate ↗
                        </Link>
                      )}

                    {/* Course Review */}
                    {canAccess && (
                      <div className="mt-9">
                        <CourseReviewForm
                          courseId={courseId}
                        />
                      </div>
                    )}
                  </section>

                  {/* Progress Panel */}
                  <aside className="rounded-2xl bg-[#f5f8f3] p-5 lg:sticky lg:top-24">
                    <div className="flex items-center justify-between">
                      <h2 className="font-semibold">
                        Your progress
                      </h2>

                      {hasPercent && (
                        <span className="text-sm font-semibold text-[#2b6045]">
                          {Math.round(safePercent)}%
                        </span>
                      )}
                    </div>

                    {hasPercent && (
                      <div
                        className="mt-4 h-2 overflow-hidden rounded-full bg-[#e1eae0]"
                        role="progressbar"
                        aria-label="Course completion"
                        aria-valuemin={0}
                        aria-valuemax={100}
                        aria-valuenow={safePercent}
                      >
                        <div
                          className="h-full rounded-full bg-[#477b56]"
                          style={{
                            width: `${safePercent}%`,
                          }}
                        />
                      </div>
                    )}

                    {progressValues.completed != null &&
                      progressValues.total != null && (
                        <p className="mt-3 text-xs leading-5 text-[#748477]">
                          {progressValues.completed} of{" "}
                          {progressValues.total} lessons
                          completed
                        </p>
                      )}

                    {progressError && (
                      <p
                        role="alert"
                        className="mt-3 text-xs leading-5 text-[#97513d]"
                      >
                        {progressError}
                      </p>
                    )}

                    {canAccess && start && (
                      <Link
                        prefetch={false}
                        href={start}
                        className={`${primary} mt-5 w-full`}
                      >
                        {course.completed ||
                        enrollmentStatus === "COMPLETED"
                          ? "Review lessons"
                          : course.lastLessonId
                          ? "Continue learning"
                          : "Start learning"}{" "}
                        →
                      </Link>
                    )}

                    <button
                      type="button"
                      onClick={() => void load()}
                      className="mt-3 w-full py-2 text-xs font-semibold text-[#5b7964] hover:underline"
                    >
                      Refresh progress
                    </button>
                  </aside>
                </div>
              </>
            ) : (
              /* Course Access / Enrollment */
              <div className="mt-8 max-w-xl">
                <h1 className="font-[Georgia,serif] text-3xl">
                  Course access
                </h1>

                {error && (
                  <p
                    role="alert"
                    className="mt-4 text-sm leading-6 text-[#97513d]"
                  >
                    {error}
                  </p>
                )}

                {status === 401 && (
                  <Link
                    href={`/auth/login?next=${encodeURIComponent(
                      pathname
                    )}`}
                    className={`${primary} mt-5`}
                  >
                    Sign in to continue
                  </Link>
                )}

                {[403, 404].includes(status) && (
                  <>
                    <p className="mt-3 text-sm leading-7 text-[#6c806f]">
                      If you are not enrolled, request
                      course access. Any pricing,
                      membership or access requirements
                      are checked by the service.
                    </p>

                    <div className="mt-5">
                      <MembershipDiscount
                        courseId={courseId}
                      />
                    </div>

                    <button
                      type="button"
                      onClick={enroll}
                      disabled={working}
                      className={`${primary} mt-5`}
                    >
                      {working
                        ? "Requesting…"
                        : "Request enrollment"}
                    </button>
                  </>
                )}

                <button
                  type="button"
                  onClick={() => void load()}
                  className="mt-5 block text-sm font-semibold text-[#315c42] hover:underline"
                >
                  Retry loading
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </main>
  );
}
