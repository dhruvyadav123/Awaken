"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { RecordMedia, RecordDetails } from "@/components/common/ApiRecordDisplay";
import { accountFetch } from "@/lib/client-account";
import { externalUrl } from "@/lib/learning-data";
import { useApi, rowsOf } from "@/components/common/dashboard/data";
import { Pagination } from "@/components/common/dashboard/Elements";

export default function MyMeditations({ meditationId }) {
  const [page, setPage] = useState(1);
  const state = useApi(meditationId ? `me/meditations/${encodeURIComponent(meditationId)}` : `me/meditations?page=${page}&limit=20`);
  const meditation = meditationId ? state.data?.meditation || state.data : null;
  const content = useApi(meditation?.hasAccess === true ? `me/meditations/${encodeURIComponent(meditationId)}/content` : null);
  const [link, setLink] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [expiresAt, setExpiresAt] = useState(0);
  const [expired, setExpired] = useState(false);
  const lock = useRef(false);

  useEffect(() => {
    if (!expiresAt) return undefined;
    const timer = setTimeout(() => setExpired(true), Math.max(0, expiresAt - Date.now()));
    return () => clearTimeout(timer);
  }, [expiresAt]);

  async function access() {
    if (lock.current || meditation?.hasAccess !== true) return;
    lock.current = true;
    setBusy(true);
    setError("");
    setLink("");
    try {
      const value = (await accountFetch(`me/meditations/${encodeURIComponent(meditationId)}/access-link`, { method: "POST", body: {} })).data;
      const url = externalUrl(value);
      if (!url) throw Error("Meditation access is unavailable. Please try again.");
      setLink(url);
      setExpired(false);
      setExpiresAt(value.expiresIn > 0 ? Date.now() + value.expiresIn * 1000 : 0);
    } catch (caught) {
      setError(caught.message);
    } finally {
      lock.current = false;
      setBusy(false);
    }
  }

  const items = rowsOf(state.data, ["meditations"]);
  const kind = content.data?.contentType || meditation?.contentType;
  const text = typeof content.data === "string" ? content.data : content.data?.content || content.data?.body || content.data?.text || content.data?.script;
  function mediaError() {
    setLink("");
    setError("Playback is unavailable. Request fresh access and try again.");
  }

  return <main className="min-h-[65vh] bg-[#f7f8f3] px-5 py-12 text-[#29473c]"><div className="mx-auto max-w-4xl">
    <Link href={meditationId ? "/profile/meditations" : "/profile"} className="text-sm underline">Back</Link>
    <h1 className="mt-8 font-[Georgia,serif] text-4xl">{meditationId ? meditation?.title || "Meditation" : "My meditations"}</h1>
    <button className="mt-4 text-sm underline" disabled={state.loading || busy} onClick={state.reload}>Refresh meditations</button>
    {state.loading && <p role="status" className="mt-6">Loading meditations…</p>}
    {(state.error || error) && <p role="alert" className="mt-6 text-[#8a4c3c]">{error || state.error}</p>}
    {!state.loading && !state.error && (meditationId ? meditation && <div className="mt-8 space-y-5">
      <RecordMedia record={meditation} imagesOnly />
      <RecordDetails record={meditation} />
      {meditation.description && <p className="leading-7 text-[#647368]">{meditation.description}</p>}
      {meditation.hasAccess !== true && <p role="status">Access is currently unavailable. <Link href="/profile/membership" className="underline">Check your membership</Link>, then refresh this meditation.</p>}
      {content.loading && <p role="status">Loading meditation content…</p>}
      {content.error && <p role="alert">{content.error} <button onClick={content.reload} className="underline">Retry content</button></p>}
      {text && <div className="whitespace-pre-line rounded-xl bg-white p-6 leading-8">{text}</div>}
      <button disabled={busy || meditation.hasAccess !== true || content.loading || Boolean(content.error)} onClick={access} className="rounded-md bg-[#315a48] px-5 py-3 text-sm font-semibold text-white disabled:opacity-50">{busy ? "Preparing…" : link ? "Refresh meditation access" : "Get meditation access"}</button>
      {expired && <p role="status" className="text-sm">Access has expired. Refresh meditation access if playback stops.</p>}
      {link && kind === "AUDIO" && <audio key={link} aria-label={meditation.title} controls preload="metadata" src={link} onError={mediaError} className="w-full" />}
      {link && kind === "VIDEO" && <video key={link} aria-label={meditation.title} controls playsInline preload="metadata" src={link} onError={mediaError} className="w-full bg-black" />}
      {link && <a href={link} target="_blank" rel="noopener noreferrer" className="block text-sm font-semibold underline">Open meditation resource</a>}
    </div> : <>
      {items.length ? <div className="mt-8 grid gap-4 sm:grid-cols-2">{items.map((item) => <article key={item.id} className="rounded-xl border border-[#dfe7dd] bg-white p-6">
        <RecordMedia record={item} compact imagesOnly />
        <h2 className="font-[Georgia,serif] text-2xl">{item.title}</h2>
        <p className="mt-2 text-sm">{item.contentType}{item.duration > 0 && ` · ${Math.round(item.duration / 60)} minutes`}</p>
        <p className="mt-2 text-sm">{item.hasAccess ? "Available in your account" : "Access unavailable"}</p>
        <Link href={`/profile/meditations/${encodeURIComponent(item.id)}`} className="mt-4 inline-block text-sm font-semibold underline">Open meditation</Link>
      </article>)}</div> : <p className="mt-8 rounded-xl bg-white p-6">No meditations are available in your account yet. <Link href="/meditations" className="underline">Browse meditations</Link></p>}
      <Pagination page={page} pagination={state.pagination} count={items.length} loading={state.loading} onChange={setPage} />
    </>)}
  </div></main>;
}
