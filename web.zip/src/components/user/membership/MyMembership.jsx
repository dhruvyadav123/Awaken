
"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { accountFetch } from "@/lib/client-account";
import { useApi, rowsOf } from "@/components/common/dashboard/data";
import { Pagination } from "@/components/common/dashboard/Elements";
import { externalUrl, titleOf } from "@/lib/learning-data";
import {
  allAccountPages,
  formatSchedule,
  requiredVersion,
} from "@/lib/student-flow";
import {
  availablePlan,
  money,
  planBenefits,
  planPeriod,
  planPrice,
  readableStatus,
} from "@/lib/membership-ui";

const primaryButton =
  "inline-flex min-h-11 items-center justify-center rounded-lg bg-[#315a48] px-5 text-sm font-semibold text-white transition hover:bg-[#264737] disabled:cursor-not-allowed disabled:opacity-50";

const outlineButton =
  "inline-flex min-h-11 items-center justify-center rounded-lg border border-[#cbd8cd] px-5 text-sm font-semibold text-[#315a48] transition hover:bg-[#f4f8f4] disabled:cursor-not-allowed disabled:opacity-50";

function displayDate(value) {
  return value ? formatSchedule(value) : "—";
}

function newIdempotencyKey() {
  if (globalThis.crypto?.randomUUID) {
    return globalThis.crypto.randomUUID();
  }

  return `membership-${Date.now()}-${Math.random()
    .toString(36)
    .slice(2)}`;
}

function Alert({ message, kind = "error" }) {
  if (!message) return null;

  return (
    <p
      role={kind === "error" ? "alert" : "status"}
      className={`rounded-lg px-4 py-3 text-sm leading-6 ${
        kind === "error"
          ? "bg-[#fff4f0] text-[#9a493b]"
          : "bg-[#edf5ee] text-[#315a48]"
      }`}
    >
      {message}
    </p>
  );
}

function Benefits({ plan }) {
  const benefits = planBenefits(plan);

  if (!benefits.length) return null;

  return (
    <div className="mt-6 border-t border-[#ecf0ec] pt-5">
      <h3 className="text-sm font-semibold text-[#314938]">
        Included in your plan
      </h3>

      <ul className="mt-3 grid gap-x-5 gap-y-2 sm:grid-cols-2">
        {benefits.map((benefit, index) => (
          <li
            key={`${benefit}-${index}`}
            className="flex gap-2 text-sm leading-6 text-[#607164]"
          >
            <span
              aria-hidden="true"
              className="font-bold text-[#3f8157]"
            >
              ✓
            </span>
            <span>{benefit}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function MembershipDiscount({ courseId }) {
  const state = useApi(
    courseId
      ? `me/membership-discount?resourceType=COURSE&resourceId=${encodeURIComponent(
          courseId
        )}`
      : null
  );

  if (!courseId) return null;

  if (state.loading) {
    return (
      <p role="status" className="text-sm text-[#6c7b70]">
        Checking membership pricing…
      </p>
    );
  }

  if (state.error) {
    return (
      <p
        role="alert"
        className="text-sm text-[#9a493b]"
      >
        {state.error}{" "}
        <button
          type="button"
          className="font-semibold underline"
          onClick={state.reload}
        >
          Retry
        </button>
      </p>
    );
  }

  const discount = state.data;

  if (!discount) return null;

  const percent =
    discount.membershipDiscountPercent;

  const finalAmount = money(
    discount.finalAmount,
    discount.currency || "INR"
  );

  const description =
    discount.included === true
      ? "Included with your membership."
      : [
          percent != null
            ? `Membership discount: ${percent}%`
            : null,

          finalAmount
            ? `Final price: ${finalAmount}`
            : null,

          discount.paymentRequired === false
            ? "No payment required."
            : null,
        ]
          .filter(Boolean)
          .join(" · ");

  if (!description) return null;

  return (
    <div className="rounded-xl border border-[#dbe9dc] bg-[#f3f8f3] px-4 py-3 text-sm leading-6 text-[#315a48]">
      {description}{" "}
      <Link
        href="/profile/membership"
        className="font-semibold underline"
      >
        View membership
      </Link>
    </div>
  );
}

export default function MyMembership({
  membershipId = "",
  planId = "",
}) {
  const detailsMode = Boolean(membershipId);

  const [selection, setSelection] = useState({
    loading: Boolean(planId),
    plan: null,
    error: "",
  });

  const [page, setPage] = useState(1);
  const [working, setWorking] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [reason, setReason] = useState("");
  const [cancelOpen, setCancelOpen] = useState(false);
  const [receipt, setReceipt] = useState(null);

  const busyRef = useRef(false);
  const idempotencyKeys = useRef({});

  const current = useApi(
    detailsMode
      ? `me/membership/${encodeURIComponent(membershipId)}`
      : "me/membership"
  );

  const history = useApi(
    detailsMode
      ? null
      : `me/membership/history?page=${page}&limit=20`
  );

  // Load the selected public plan.
  useEffect(() => {
    if (!planId || detailsMode) return;

    let live = true;

    queueMicrotask(() => {
      if (!live) return;

      setSelection({
        loading: true,
        plan: null,
        error: "",
      });
    });

    allAccountPages(
      accountFetch,
      "public/membership-plans",
      ["plans", "membershipPlans", "items"]
    )
      .then((plans) => {
        if (!live) return;

        const plan = plans.find(
          (item) =>
            String(item?.id) === String(planId) &&
            availablePlan(item)
        );

        setSelection({
          loading: false,
          plan: plan || null,
          error: plan
            ? ""
            : "This plan is no longer available. Choose another plan.",
        });
      })
      .catch((caught) => {
        if (!live) return;

        setSelection({
          loading: false,
          plan: null,
          error:
            caught?.message ||
            "Unable to load the selected plan.",
        });
      });

    return () => {
      live = false;
    };
  }, [planId, detailsMode]);

  const memberships = rowsOf(
    current.data,
    ["memberships"]
  );

  const membership =
    current.data?.membership ||
    (current.data?.id ? current.data : null) ||
    (!detailsMode
      ? memberships.find(
          (item) => item.hasAccess === true
        ) || memberships[0]
      : null) ||
    null;

  const entries = rowsOf(
    history.data,
    ["history", "memberships"]
  );

  const isMissing = current.status === 404;

  const loadError = isMissing
    ? ""
    : current.error;

  const status = String(
    membership?.status || ""
  ).toUpperCase();

  const terminal = [
    "CANCELLED",
    "CANCELED",
    "EXPIRED",
    "REVOKED",
  ].includes(status);

  const hasOngoingMembership = Boolean(
    membership && !terminal
  );

  const selectedPlan =
    selection.plan &&
    String(selection.plan.id) === String(planId)
      ? selection.plan
      : null;

  const renewal = membership?.renewal;

  // An expired membership can still be renewable
  // when the backend explicitly marks it eligible.
  const canRenew =
    renewal?.eligible === true &&
    membership?.version != null;

  const canCancel = Boolean(
    detailsMode &&
    membership &&
    !terminal &&
    membership.version != null
  );

  const paymentLink =
    externalUrl(receipt?.payment) ||
    externalUrl(receipt?.checkout);

  const orderId =
    receipt?.orderId ||
    receipt?.order?.id ||
    receipt?.period?.orderId;

  function keyFor(key) {
    if (!idempotencyKeys.current[key]) {
      idempotencyKeys.current[key] =
        newIdempotencyKey();
    }

    return idempotencyKeys.current[key];
  }

  async function refresh() {
    if (busyRef.current) return;

    setError("");

    await Promise.all([
      current.reload(),
      ...(detailsMode ? [] : [history.reload()]),
    ]);
  }

  // Actual backend mutations.
  async function act(action) {
    if (busyRef.current) return;

    busyRef.current = true;
    setWorking(action);
    setError("");
    setNotice("");

    try {
      let path;
      let body;
      let keyName;

      if (action === "activate") {
        if (!planId || !selectedPlan) {
          throw new Error(
            "Choose an available plan first."
          );
        }

        if (hasOngoingMembership) {
          throw new Error(
            "Manage your existing membership before selecting another plan."
          );
        }

        keyName = `activate-${planId}`;
        path = "me/membership/activate";

        body = {
          planId,
          idempotencyKey: keyFor(keyName),
        };
      } else {
        if (!membership?.id) {
          throw new Error(
            "Membership details are unavailable."
          );
        }

        if (action === "renew" && !canRenew) {
          throw new Error(
            "Renewal is not currently available."
          );
        }

        if (action === "cancel" && !canCancel) {
          throw new Error(
            "Cancellation is not available for this membership."
          );
        }

        if (action === "cancel" && !reason.trim()) {
          throw new Error(
            "Enter a cancellation reason."
          );
        }

        const version = requiredVersion(
          membership.version,
          "membership"
        );

        path = `me/membership/${encodeURIComponent(
          String(membership.id)
        )}/${action}`;

        if (action === "renew") {
          keyName = `renew-${membership.id}`;

          body = {
            version,
            idempotencyKey: keyFor(keyName),
          };
        } else {
          body = {
            version,
            reason: reason.trim(),
          };
        }
      }

      const response = await accountFetch(path, {
        method: "POST",
        body,
      });

      setReceipt(response?.data || null);

      setNotice(
        response?.message ||
          "Request submitted. Check the latest membership status below."
      );

      if (keyName) {
        delete idempotencyKeys.current[keyName];
      }

      if (action === "cancel") {
        setCancelOpen(false);
        setReason("");
      }

      try {
        await Promise.all([
          current.reload(),
          ...(detailsMode
            ? []
            : [history.reload()]),
        ]);
      } catch {
        setNotice(
          "Request submitted successfully. Use Refresh to load the updated membership details."
        );
      }
    } catch (caught) {
      if (caught?.status === 409) {
        setError(
          "Membership details changed on the server. Review the latest information and try again."
        );

        await current.reload();
      } else {
        setError(
          caught?.message ||
            "The membership request failed. Please try again."
        );
      }
    } finally {
      busyRef.current = false;
      setWorking("");
    }
  }

  const otherMemberships = memberships.filter(
    (item) =>
      item.id &&
      String(item.id) !== String(membership?.id)
  );

  return (
    <main className="min-h-[65vh] bg-white px-4 py-8 text-[#293f33] sm:px-6 sm:py-10">
      <div className="mx-auto max-w-5xl">

        {/* Header */}
        <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[#e8ede8] pb-6">
          <div>
            <Link
              href={
                detailsMode
                  ? "/profile/membership"
                  : "/profile"
              }
              className="text-xs font-semibold text-[#52715b] hover:underline"
            >
              ← {detailsMode ? "My membership" : "My account"}
            </Link>

            <h1 className="mt-3 text-3xl font-semibold tracking-tight text-[#233c2f] sm:text-4xl">
              {detailsMode
                ? "Manage membership"
                : "My membership"}
            </h1>

            <p className="mt-2 text-sm text-[#748276]">
              {detailsMode
                ? "View your plan and available actions."
                : "View your access, payments and membership history."}
            </p>
          </div>

          <button
            type="button"
            className={outlineButton}
            disabled={
              current.loading || Boolean(working)
            }
            onClick={refresh}
          >
            Refresh
          </button>
        </div>

        {/* API messages and payment */}
        <div className="mt-5 space-y-3">
          <Alert message={error || loadError} />
          <Alert message={notice} kind="success" />

          {orderId && (
            <Link
              href={`/profile/orders/${encodeURIComponent(
                String(orderId)
              )}`}
              className="inline-flex text-sm font-semibold text-[#315a48] underline"
            >
              View related order
            </Link>
          )}

          {paymentLink && (
            <a
              href={paymentLink}
              target="_blank"
              rel="noopener noreferrer"
              className={`${primaryButton} w-fit`}
            >
              Continue payment →
            </a>
          )}
        </div>

        {current.loading ? (
          <p
            role="status"
            className="py-12 text-sm text-[#6b7d70]"
          >
            Loading membership…
          </p>
        ) : detailsMode && isMissing ? (
          <div className="py-12">
            <p className="text-sm text-[#68786b]">
              This membership could not be found.
            </p>

            <Link
              href="/profile/membership"
              className="mt-3 inline-flex text-sm font-semibold text-[#315a48] underline"
            >
              Back to my membership
            </Link>
          </div>
        ) : !loadError && (
          <div className="mt-7 space-y-7">

            {/* Current membership */}
            {membership ? (
              <section
                className="rounded-xl border border-[#e0e9e1] p-5 sm:p-7"
                aria-labelledby="current-membership-heading"
              >
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-[0.12em] text-[#738675]">
                      Membership
                    </p>

                    <h2
                      id="current-membership-heading"
                      className="mt-2 text-2xl font-semibold tracking-tight text-[#243e30]"
                    >
                      {titleOf(
                        membership.plan,
                        "Membership plan"
                      )}
                    </h2>

                    <div className="mt-3 flex flex-wrap items-center gap-3 text-sm">
                      {membership.status && (
                        <span className="rounded-full bg-[#edf4ed] px-3 py-1 text-xs font-semibold text-[#3c6548]">
                          {readableStatus(
                            membership.status
                          )}
                        </span>
                      )}

                      {typeof membership.hasAccess ===
                        "boolean" && (
                        <span className="text-[#647468]">
                          {membership.hasAccess
                            ? "Access available"
                            : "Access unavailable"}
                        </span>
                      )}
                    </div>
                  </div>

                  {!detailsMode && membership.id && (
                    <Link
                      href={`/profile/membership/${encodeURIComponent(
                        String(membership.id)
                      )}`}
                      className={primaryButton}
                    >
                      Manage membership →
                    </Link>
                  )}
                </div>

                <dl className="mt-6 grid gap-5 border-t border-[#edf0ed] pt-5 text-sm sm:grid-cols-3">
                  {membership.currentPeriod?.startsAt && (
                    <div>
                      <dt className="text-[#758577]">
                        Period start
                      </dt>

                      <dd className="mt-1 font-medium text-[#294536]">
                        {displayDate(
                          membership.currentPeriod.startsAt
                        )}
                      </dd>
                    </div>
                  )}

                  {(membership.currentPeriod?.expiresAt ||
                    membership.expiresAt) && (
                    <div>
                      <dt className="text-[#758577]">
                        Access until
                      </dt>

                      <dd className="mt-1 font-medium text-[#294536]">
                        {displayDate(
                          membership.currentPeriod
                            ?.expiresAt ||
                            membership.expiresAt
                        )}
                      </dd>
                    </div>
                  )}

                  {typeof membership.autoRenew ===
                    "boolean" && (
                    <div>
                      <dt className="text-[#758577]">
                        Auto-renewal
                      </dt>

                      <dd className="mt-1 font-medium text-[#294536]">
                        {membership.autoRenew
                          ? "Enabled"
                          : "Disabled"}
                      </dd>
                    </div>
                  )}
                </dl>

                <Benefits plan={membership.plan} />
              </section>
            ) : (
              <section className="rounded-xl border border-[#e0e9e1] px-5 py-8 sm:px-7">
                <h2 className="text-lg font-semibold text-[#263f30]">
                  No current membership
                </h2>

                <p className="mt-2 text-sm text-[#728074]">
                  Choose a plan to get started.
                </p>

                {!planId && (
                  <Link
                    href="/infinity/membership"
                    className={`${primaryButton} mt-5 w-fit`}
                  >
                    Explore membership plans →
                  </Link>
                )}
              </section>
            )}

            {/* Other memberships */}
            {!detailsMode &&
              otherMemberships.length > 0 && (
                <section aria-labelledby="other-memberships-heading">
                  <h2
                    id="other-memberships-heading"
                    className="text-lg font-semibold text-[#263f30]"
                  >
                    Other memberships
                  </h2>

                  <div className="mt-3 divide-y divide-[#e7ede7] border-y border-[#e7ede7]">
                    {otherMemberships.map((item) => (
                      <div
                        key={item.id}
                        className="flex flex-wrap items-center justify-between gap-3 py-3 text-sm"
                      >
                        <span>
                          {titleOf(
                            item.plan,
                            "Membership"
                          )}
                          {" · "}
                          {readableStatus(item.status)}
                        </span>

                        <Link
                          href={`/profile/membership/${encodeURIComponent(
                            String(item.id)
                          )}`}
                          className="font-semibold text-[#315a48] hover:underline"
                        >
                          View details →
                        </Link>
                      </div>
                    ))}
                  </div>
                </section>
              )}

            {/* Selected plan activation */}
            {!detailsMode && planId && (
              <section
                className="rounded-xl border border-[#d8e5d9] bg-[#f8fbf8] p-5 sm:p-7"
                aria-labelledby="chosen-plan-heading"
              >
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-[0.12em] text-[#66806a]">
                      Selected plan
                    </p>

                    <h2
                      id="chosen-plan-heading"
                      className="mt-2 text-xl font-semibold text-[#254430]"
                    >
                      {selectedPlan?.name ||
                        selectedPlan?.title ||
                        "Membership plan"}
                    </h2>

                    {selectedPlan && (
                      <p className="mt-2 text-sm text-[#637566]">
                        <span className="text-lg font-semibold text-[#294735]">
                          {planPrice(selectedPlan)
                            .current ||
                            "Price unavailable"}
                        </span>

                        {planPeriod(selectedPlan) && (
                          <span className="ml-2">
                            {planPeriod(selectedPlan)}
                          </span>
                        )}
                      </p>
                    )}
                  </div>

                  <Link
                    href="/infinity/membership"
                    className="text-sm font-semibold text-[#315a48] hover:underline"
                  >
                    Change plan →
                  </Link>
                </div>

                {selection.loading && (
                  <p
                    role="status"
                    className="mt-4 text-sm text-[#6d7d70]"
                  >
                    Loading selected plan…
                  </p>
                )}

                <Alert message={selection.error} />

                {selectedPlan && (
                  <Benefits plan={selectedPlan} />
                )}

                {hasOngoingMembership && (
                  <p className="mt-4 text-sm text-[#7b6652]">
                    You already have a membership
                    that has not ended. Manage it
                    before activating a new plan.
                  </p>
                )}

                <button
                  type="button"
                  className={`${primaryButton} mt-5 w-full sm:w-auto`}
                  disabled={
                    Boolean(working) ||
                    selection.loading ||
                    !selectedPlan ||
                    hasOngoingMembership ||
                    current.loading
                  }
                  onClick={() => act("activate")}
                >
                  {working === "activate"
                    ? "Processing…"
                    : "Activate selected plan →"}
                </button>

                <p className="mt-3 text-xs leading-5 text-[#78877b]">
                  Any required payment is handled
                  through the checkout details
                  returned by the server.
                </p>
              </section>
            )}

            {/* Renewal and cancellation */}
            {detailsMode &&
              membership &&
              (canRenew || canCancel) && (
                <section
                  className="grid gap-5 md:grid-cols-2"
                  aria-label="Manage membership actions"
                >
                  {canRenew && (
                    <div className="rounded-xl border border-[#e0e9e1] p-5 sm:p-6">
                      <h2 className="text-lg font-semibold text-[#254330]">
                        Renew membership
                      </h2>

                      <p className="mt-2 text-sm leading-6 text-[#68786d]">
                        {renewal.durationDays
                          ? `${renewal.durationDays} days`
                          : "Renew membership"}

                        {money(
                          renewal.amount,
                          renewal.currency ||
                            membership.plan?.currency ||
                            "INR"
                        )
                          ? ` · ${money(
                              renewal.amount,
                              renewal.currency ||
                                membership.plan
                                  ?.currency ||
                                "INR"
                            )}`
                          : ""}

                        {typeof renewal.paymentRequired ===
                        "boolean"
                          ? renewal.paymentRequired
                            ? " · Payment required"
                            : " · No payment required"
                          : ""}
                      </p>

                      <button
                        type="button"
                        className={`${primaryButton} mt-5`}
                        disabled={Boolean(working)}
                        onClick={() => act("renew")}
                      >
                        {working === "renew"
                          ? "Processing…"
                          : "Renew membership →"}
                      </button>
                    </div>
                  )}

                  {canCancel && (
                    <div className="rounded-xl border border-[#e0e9e1] p-5 sm:p-6">
                      <h2 className="text-lg font-semibold text-[#254330]">
                        Cancel membership
                      </h2>

                      {!cancelOpen ? (
                        <>
                          <p className="mt-2 text-sm leading-6 text-[#68786d]">
                            Request cancellation of
                            this membership.
                          </p>

                          <button
                            type="button"
                            className={`${outlineButton} mt-5`}
                            disabled={Boolean(working)}
                            onClick={() =>
                              setCancelOpen(true)
                            }
                          >
                            Cancel membership
                          </button>
                        </>
                      ) : (
                        <form
                          className="mt-4"
                          onSubmit={(event) => {
                            event.preventDefault();
                            void act("cancel");
                          }}
                        >
                          <label
                            htmlFor="cancellation-reason"
                            className="block text-sm font-medium text-[#415647]"
                          >
                            Reason for cancellation
                          </label>

                          <textarea
                            id="cancellation-reason"
                            value={reason}
                            onChange={(event) =>
                              setReason(
                                event.target.value
                              )
                            }
                            maxLength={500}
                            required
                            disabled={Boolean(working)}
                            rows={3}
                            className="mt-2 w-full rounded-lg border border-[#cedace] bg-white p-3 text-sm outline-none focus:border-[#315a48]"
                          />

                          <div className="mt-3 flex flex-wrap gap-3">
                            <button
                              type="submit"
                              className="inline-flex min-h-10 items-center justify-center rounded-lg bg-[#9a493b] px-4 text-sm font-semibold text-white hover:bg-[#803a2e] disabled:opacity-50"
                              disabled={
                                Boolean(working) ||
                                !reason.trim()
                              }
                            >
                              {working === "cancel"
                                ? "Processing…"
                                : "Confirm cancellation"}
                            </button>

                            <button
                              type="button"
                              className="px-3 text-sm font-semibold text-[#5f7164] hover:underline"
                              disabled={Boolean(working)}
                              onClick={() => {
                                setCancelOpen(false);
                                setReason("");
                              }}
                            >
                              Keep membership
                            </button>
                          </div>
                        </form>
                      )}
                    </div>
                  )}
                </section>
              )}

            {/* Membership history - overview only */}
            {!detailsMode && (
              <section
                className="pt-2"
                aria-labelledby="history-heading"
              >
                <h2
                  id="history-heading"
                  className="text-xl font-semibold tracking-tight text-[#243e30]"
                >
                  Membership history
                </h2>

                <p className="mt-1 text-sm text-[#758376]">
                  Past periods and membership activity.
                </p>

                {history.loading ? (
                  <p
                    role="status"
                    className="py-6 text-sm text-[#68796d]"
                  >
                    Loading history…
                  </p>
                ) : history.error ? (
                  <div className="py-5">
                    <Alert message={history.error} />

                    <button
                      type="button"
                      className="mt-3 text-sm font-semibold text-[#315a48] underline"
                      onClick={history.reload}
                    >
                      Retry history
                    </button>
                  </div>
                ) : entries.length === 0 ? (
                  <p className="py-6 text-sm text-[#728276]">
                    No membership history yet.
                  </p>
                ) : (
                  <div className="mt-4 divide-y divide-[#e5ece5] border-y border-[#e5ece5]">
                    {entries.map((entry, index) => (
                      <div
                        key={
                          entry.id ||
                          `history-${index}`
                        }
                        className="flex flex-wrap items-center justify-between gap-3 py-4"
                      >
                        <div>
                          <h3 className="text-sm font-semibold text-[#2e4837]">
                            {titleOf(
                              entry.plan,
                              "Membership period"
                            )}
                          </h3>

                          <p className="mt-1 text-xs text-[#728175]">
                            {[
                              entry.operation,
                              entry.membershipStatus,
                              entry.paymentStatus,
                            ]
                              .filter(Boolean)
                              .map(readableStatus)
                              .join(" · ")}
                          </p>

                          {(entry.startsAt ||
                            entry.expiresAt) && (
                            <p className="mt-1 text-xs text-[#728175]">
                              {displayDate(
                                entry.startsAt
                              )}
                              {" — "}
                              {displayDate(
                                entry.expiresAt
                              )}
                            </p>
                          )}
                        </div>

                        {entry.membershipId && (
                          <Link
                            href={`/profile/membership/${encodeURIComponent(
                              String(
                                entry.membershipId
                              )
                            )}`}
                            className="text-sm font-semibold text-[#315a48] hover:underline"
                          >
                            View →
                          </Link>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                <Pagination
                  page={page}
                  pagination={history.pagination}
                  count={entries.length}
                  loading={history.loading}
                  onChange={setPage}
                />
              </section>
            )}

          </div>
        )}
      </div>
    </main>
  );
}
