import ContentPage from "../../../components/common/ContentPage";
import { pages } from "../../../data/site-pages";
export const metadata = { title: "Terms of Use | AwakenWithMeheck" };
export default function TermsPage() { return <ContentPage {...pages.terms} />; }
