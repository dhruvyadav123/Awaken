import ContentPage from "../../../components/common/ContentPage";
import { pages } from "../../../data/site-pages";
export const metadata = { title: "Privacy Policy | AwakenWithMeheck" };
export default function PrivacyPage() { return <ContentPage {...pages.privacy} />; }
