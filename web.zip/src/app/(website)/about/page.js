import ContentPage from "../../../components/common/ContentPage";
import AboutFaqs from "../../../components/website/about/AboutFaqs";
import { pages } from "../../../data/site-pages";
import { getCmsPayload, getTextValue, safeLink } from "../../../lib/cms-content";
import { allPublicItems, publicApi } from "../../../lib/public-api";

export const metadata = { title: "About | AwakenWithMeheck" };

function publicMediaPath(mediaId) {
  return typeof mediaId === "string" && /^[a-f\d]{24}$/i.test(mediaId)
    ? `/api/public/files/media/${encodeURIComponent(mediaId)}/file`
    : "";
}

function markdownLink(value) {
  if (typeof value !== "string") return null;
  const raw = value.trim();
  const match = raw.match(/^\[([^\]]+)\]\((https?:\/\/[^)]+)\)$/i);
  const href = safeLink(match ? match[2] : raw, { allowExternal: true });
  return href ? { label: match?.[1]?.trim() || href, href } : null;
}

function videoSource(payload) {
  const link = [
    "videoUrl",
    "videoLink",
    "video",
    "introductionVideoUrl",
    "recordingUrl",
    "linkUrl",
  ]
    .map((key) => markdownLink(payload?.[key]))
    .find(Boolean);

  if (link) return link.href;

  return publicMediaPath(
    payload?.videoMediaId ||
      payload?.introductionVideoMediaId ||
      payload?.recordingMediaId
  );
}

function apiSection(record, index) {
  const section = getCmsPayload(record);
  const heading = getTextValue(section, "heading", "title");
  const body = getTextValue(section, "text", "content", "body", "description");
  const link = markdownLink(section.linkUrl) || markdownLink(section.linkLabel);
  const labelLink = markdownLink(section.linkLabel);
  const image = publicMediaPath(section.imageMediaId);

  if (!heading && !body && !link) return null;

  return {
    heading: heading || `About Awaken ${index + 1}`,
    body,
    links: link ? [{ label: link.label, description: labelLink?.label && labelLink.label !== link.label ? labelLink.label : "Learn more.", href: link.href }] : [],
    ...(image ? { image } : {}),
  };
}

async function aboutContent() {
  const [pageResult, sectionResult] = await Promise.all([
    publicApi("pages/about"),
    allPublicItems("cms/sections"),
  ]);

  const page = pageResult.data;
  const pageData = page || {};
  const hero = Array.isArray(pageData.blocks)
    ? pageData.blocks.find((block) => String(block?.type || "").toUpperCase() === "HERO") || pageData.blocks[0]
    : null;
  const sectionRecords = (sectionResult.data || []).filter((item) => item?.key === "about-section" || item?.data?.key === "about-section");
  const aboutSection = sectionRecords.map(getCmsPayload).find((section) => getTextValue(section, "heading", "text", "description"));
  const sections = sectionRecords.map(apiSection).filter(Boolean);
  const apiPoster = publicMediaPath(hero?.imageMediaId) || sections.find((section) => section.image)?.image || "";
  const videoLink = [hero, pageData, aboutSection, ...sectionRecords.map(getCmsPayload)]
    .map(videoSource)
    .find(Boolean);
  const bookingLink = sectionRecords.map(getCmsPayload).map((section) => markdownLink(section.linkLabel)).find(Boolean);

  return {
    ...pages.about,
    ...(hero || page || aboutSection ? {
      title: getTextValue(hero, "heading") || page?.title || "AwakenWithMeheck",
      description: getTextValue(hero, "text", "description"),
    } : {}),
    sections,
    ...(bookingLink ? { primaryAction: { ...pages.about.primaryAction, href: bookingLink.href } } : {}),
    ...(videoLink || apiPoster ? {
      portraitVideo: {
        src: videoLink || "",
        poster: apiPoster || "",
        title: getTextValue(hero, "heading") || "Meet Meheck Mukherjee",
      },
    } : {}),
  };
}

export default function AboutPage() {
  return <AboutContent />;
}

async function AboutContent() {
  const content = await aboutContent();
  return <><ContentPage {...content} plainWhite portraitSide="left" portraitCard /><AboutFaqs /></>;
}
