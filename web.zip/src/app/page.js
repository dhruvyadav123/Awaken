
import OpeningSplash from "@/components/common/OpeningSplash";
import CinematicHero from "@/components/website/home/CmsHomeHero";
import HomeCmsSections from "@/components/website/home/HomeCmsSections";
import HomeContentSections from "@/components/website/home/HomeContentSections";
import HomepageMotion from "@/components/website/home/HomepageMotion";
import HomeAboutSection from "@/components/website/home/HomeAboutSection";
import "./home.css";

export const dynamic = "force-dynamic";

export default function Home() {
  return (
    <>
      <OpeningSplash />
      <HomepageMotion>
        <CinematicHero />
        <HomeAboutSection />
        <HomeContentSections />
        <HomeCmsSections />
      </HomepageMotion>
    </>
  );
}
